# Informes
El repositorio original ya contiene `Avance 1 21_08.pdf` y `Avance 2 25_10.pdf`: conservarlos.

Se incorpora ahora el archivo original de la tercera entrega `Avance_3_22-11-2026.docx` en esta carpeta, **sin editar**. Se complementa con las nuevas capturas y resultados de `testing/`, sin modificar retrospectivamente el informe entregado.

Para los cambios entre etapas revisar `iteraciones/`. No confundir el estado de la entrega escrita con las pruebas de laboratorio posteriores.

# Iteración 2 — Avance 2 (25/10/2026)
## Evolución
Se documentó ensamblaje con Arduino Uno, sensor DS18B20, TDS V1.0 y turbidez TSW-20M; primeras mediciones físicas y transmisión serial. Se explica promediado analógico de diez lecturas y diseño CAD inicial de aproximadamente **70 × 120 × 270 mm** según Avance 2 (expresado allí como 7 × 12 × 27 cm).

El informe incluye fotografías de ensayos con agua de llave y agua helada con sal, así como bocetos y diseño de encapsulado. **FALTA** exportación separada de esas fotografías y respaldo completo de registros crudos.

**Nota:** los valores de esta etapa son ensayos anteriores y **no se deben fusionar** con los datos de noviembre de la Iteración 3.

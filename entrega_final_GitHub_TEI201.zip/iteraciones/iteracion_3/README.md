# Iteración 3 — Avance 3 (22/11/2026)
## Evolución documentada
- Arquitectura Arduino Uno + registro EEPROM + transmisión posterior por USB a computador y ThingSpeak.
- Código fuente `software/src/EVA.ino` (aportado) y `software/src/main.ino` (ya existente en GitHub).
- Diseño declarado de encapsulado de **52 × 100 × 253 mm** y consumo estimado de **197 g de PLA**.
- Lista de materiales de trece partidas; diferencia de $3 entre total declarado ($40.876) y suma ($40.879).
- Resultados experimentales A y B del 22/11/2026 y cuatro capturas originales en `testing/evidencias/`.

**FALTA** `subir_eva.py`, esquemáticos y planos exportados, renders independientes, validación de batería/regulador y resultados completos de ensayos.

**No documentado:** 100% de precisión, cero errores, funcionamiento sanitario garantizado o fabricación física del encapsulado.

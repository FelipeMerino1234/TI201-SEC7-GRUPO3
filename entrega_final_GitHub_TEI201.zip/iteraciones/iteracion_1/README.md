# Iteración 1 — Avance 1 (29/08/2026)
## Enfoque
Problema de senderistas que necesitan evaluar características del agua antes de tratamiento con pastillas. Se define el usuario y se identifica relación con ODS 6 y ODS 3. Se propone un detector portátil con lectura de temperatura, turbidez y TDS, LED verde/rojo y encapsulado con dos secciones.

El boceto aparece incrustado en el Avance 1 original ubicado en `docs/`. **FALTA** archivo fotográfico separado y código/esquemático de esta primera versión verificables como tales. No atribuimos pruebas IoT a esta etapa.

# Historial de iteraciones
- [Iteración 1](iteracion_1/): concepto, problema, usuario y solución en Avance 1.
- [Iteración 2](iteracion_2/): sensores reales, Arduino, primer CAD y ensayos iniciales descritos en Avance 2.
- [Iteración 3](iteracion_3/): EEPROM, integración IoT, BOM, modelo Fusion, esquema EasyEDA descritos en Avance 3 y capturas 22/11.

Se conservan las tres etapas sin atribuir a la primera funciones de la tercera ni porcentajes de cumplimiento inventados.

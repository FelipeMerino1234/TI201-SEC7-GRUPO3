# Esquemas y conexiones
El Avance 3 describe esquemático en **EasyEDA**, junto con resistencia de 4,7 kΩ para DS18B20, dos resistencias de 220 Ω para los LEDs, módulo TP4056 y los pines reflejados en `hardware/README.md`.

**FALTA** subir a esta carpeta el esquema PDF/PNG oficial y archivo editable EasyEDA. No se sustituirá por un esquema ficticio.

**FALTA** verificar si el circuito real incorpora regulación/elevación a 5 V para alimentación autónoma. El TP4056 es un módulo de carga, no un elevador de voltaje por defecto.

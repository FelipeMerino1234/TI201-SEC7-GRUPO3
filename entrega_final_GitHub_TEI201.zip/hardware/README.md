# Hardware
**Plataforma:** Arduino Uno, DS18B20, TDS V1.0, TSW-20M (turbidez), dos LED, interruptor SPDT, resistencias, protoboard, jumpers, batería 18650 y módulo de carga descritos en el Avance 3.

| Parte | Pin Arduino | Función |
|---|---|---|
| Temperatura DS18B20 | D2 | Digital OneWire |
| Interruptor SPDT | D3 | Entrada con `INPUT_PULLUP` |
| TDS V1.0 | A0 | Entrada analógica |
| Turbidez TSW-20M | A1 | Entrada analógica |
| LED verde | D8 | Cumple tres umbrales |
| LED rojo | D9 | Incumple al menos un umbral |

Consultar [BOM](bom/), [Esquemas](esquemas/) y [Fotos](fotos/).

**FALTA** verificar alimentación autónoma real: batería 18650 de 3,7 V y cargador TP4056 por sí mismos no constituyen fuente regulada de 5 V para el Arduino Uno. **FALTA** evidencia de aislamiento y estanqueidad comprobados. No sumergir electrónica ni batería sin una evaluación de seguridad eléctrica.

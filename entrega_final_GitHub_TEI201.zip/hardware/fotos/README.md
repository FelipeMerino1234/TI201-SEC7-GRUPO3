# Fotografías del hardware
La documentación de los avances contiene imágenes incrustadas de prototipo y conexiones; el GitHub no incluye por separado esas imágenes en esta carpeta.

**FALTA** archivos fotográficos originales del montaje físico, interior, sensores, conexiones, módulo de alimentación y carcasa real. No confundir renders CAD con fotografías de un prototipo impreso.

Las cuatro capturas de Monitor Serial/Python están en `testing/evidencias/`, por tratarse de evidencias de prueba, no de fotos del encapsulado.

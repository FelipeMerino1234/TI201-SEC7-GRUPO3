# Estado de entrega y faltantes
**Criterio:** **FALTA** significa que no tenemos la fuente original o evidencia para sostener la afirmación; no implica que el equipo no la haya producido.

## Material incorporado en este paquete
- Avance 3 original en `docs/Avance_3_22-11-2026.docx` (sin modificar).
- Código original `software/src/EVA.ino` (sin modificar).
- Cuatro capturas originales de pruebas en `testing/evidencias/`.
- Dos CSV transcritos de capturas, datos observados separados de promedios derivados.
- README técnicos y seguimiento de iteraciones.

## Material que ya estaba en GitHub y debe conservarse
- PDFs Avances 1 y 2 en `docs/`.
- Archivo original `DISEÑO.f3d` en la raíz (dejarlo donde está hasta verificar apertura; vincularlo desde `diseno_3d/fusion360/`).
- `software/src/main.ino` (variante histórica del firmware; no reemplazar sin comparar).
- `Codigo_Arduino_V2.ipynb` y `codigo_arduino_V2.py` (versiones históricas, no código Python del gateway).
- `FUENTES.md` y licencia.

## Pendientes específicos
1. **FALTA** archivo original `subir_eva.py`: se ve ejecutándose, pero no se entregó su contenido.
2. **FALTA** esquemático oficial exportado de EasyEDA y su archivo editable.
3. **FALTA** planos técnicos PDF y renders independientes desde Fusion 360.
4. **FALTA** fotos originales del prototipo físico completo y de la fabricación de la carcasa.
5. **FALTA** exportación íntegra CSV de ThingSpeak con fechas y horas.
6. **FALTA** mediciones de latencia, exactitud metrológica, tasa de error y pruebas de estanqueidad.
7. **FALTA** registro visual del LED encendido durante las dos pruebas de noviembre.
8. **FALTA** validación microbiológica, prueba de eficacia de pastillas y demostración en campo.
9. **FALTA** confirmación del circuito elevador/regulador usado para alimentar Arduino Uno desde batería 18650; el cargador TP4056 no eleva tensión por sí solo.
10. **FALTA** confirmación de los componentes internos del archivo `DISEÑO.f3d` mediante apertura del CAD.

## Inconsistencias encontradas
- Algunas plantillas originales mencionan **ESP32/DHT22**, incompatibles con este proyecto de **Arduino Uno / DS18B20 / TDS / turbidez**.
- El Avance 3 nombra «Muestra C» aunque sólo describe dos muestras (A y B).
- BOM del Avance 3 declara $40.876 CLP, mientras sumar las 13 partidas da $40.879 CLP (diferencia $3).
- No corresponde afirmar 100% precisión, cero fallos, medición exacta de latencia ni eficacia sanitaria por dos capturas.
- En `EVA.ino` se promedian **10 lecturas analógicas** para TDS y turbidez; la temperatura se consulta una vez por ciclo.
- La encuesta de 46 participantes fue un **pre-test de percepción**, no 46 pruebas físicas de usabilidad.

# Monitor de Calidad del Agua (M.C.A. / E.V.A.)
**TEI 201 · Sección 7 · Grupo 3 · Universidad Adolfo Ibáñez**

**Integrantes:** Vicente Benjamín Corvalán Báez; Benjamín Eltit Camilla; Felipe Ignacio Merino Romero; Nicolás Ignacio Rosas Astorga; Sofía Victoria Sandoval Riquelme. **Profesor:** Benjamín Gutiérrez.

## Problema y objetivo
Excursionistas en zonas de montaña sin redes de agua potable pueden necesitar tratar agua natural sin conocer parámetros relevantes para el tratamiento. Se propone un equipo portátil basado en **Arduino Uno** para medir temperatura, sólidos disueltos totales (TDS) y turbidez, y mostrar una señal verde o roja conforme a la lógica de control.

**Umbrales programados:** temperatura **>10 °C**, TDS **<500 ppm** y turbidez **<5 NTU**. Un resultado verde indica sólo que se cumplieron los umbrales configurados: **NO certifica potabilidad, ausencia de microorganismos ni eficacia de desinfección**. Respetar instrucciones y tiempos del producto de tratamiento.

## Evolución del proyecto
- **Avance 1 (29/08/2026):** problemática, investigación, usuarios y concepto.
- **Avance 2 (25/10/2026):** arquitectura, Arduino y sensores físicos, primeras pruebas y diseño CAD.
- **Avance 3 (22/11/2026):** ampliación EEPROM e integración IoT por USB/Python, esquemático y diseño mecánico, BOM y protocolo de testing.

## Datos observados de la prueba del 22/11/2026
| Parámetro | Muestra A (llave) | Muestra B (fría con sal) |
|---|---:|---:|
| Temperatura | 21,81 °C | 5,88 °C |
| TDS | 250,10 ppm | 892,33 ppm |
| Turbidez | 0,00 NTU | 403,06 NTU |
| Evaluación de la regla de firmware | Cumple | No cumple |
| Registro reportado en consola ThingSpeak | 1 | 2 |

Son **lecturas puntuales** visibles en las capturas de subida, **no promedios completos**. Las fotografías y transcripciones están en `testing/`.

## Carpetas del proyecto
- `hardware/`: componentes, presupuesto y conexiones.
- `software/`: código fuente y documentación técnica.
- `diseno_3d/`: modelo, planos y renders.
- `testing/`: datos de pruebas y fotografías originales.
- `docs/`: informes originales, incluido Avance 3.
- `iteraciones/`: evolución de las entregas.
- `ESTADO_ENTREGA.md`: inventario de ausencias, todas marcadas **FALTA**.

## Cómo usar el firmware
Instalar Arduino IDE, OneWire y DallasTemperature. Abrir `software/src/EVA.ino` y seleccionar **Arduino Uno**. Cargar el firmware y usar Monitor Serial a **9600 baudios**. El comando `L` lista muestras EEPROM en formato CSV; `B` borra el historial. El archivo original `subir_eva.py` utilizado para enviar datos a ThingSpeak todavía **FALTA** en este paquete.

Canal ThingSpeak indicado por el equipo: https://thingspeak.mathworks.com/channels/3588837

## Fuentes y criterios
La documentación se basa exclusivamente en los tres informes, el código `EVA.ino` y las cuatro capturas proporcionadas. Se distingue entre comportamiento programado, pruebas observadas, diseños CAD y verificaciones pendientes. No se inventan resultados.

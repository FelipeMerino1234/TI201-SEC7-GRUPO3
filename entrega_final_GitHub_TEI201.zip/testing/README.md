# Testing y validación
Se distinguen el **pre-test de percepción con 46 encuestados** y las **pruebas físicas con dos muestras de agua**. No son el mismo experimento.

## Protocolo de Avance 3
- Muestra A: agua de la llave a temperatura ambiente.
- Muestra B: agua enfriada con hielo y sal.
- Lecturas de temperatura, TDS y turbidez mediante Arduino; registro EEPROM y confirmación de subida a ThingSpeak.
- **FALTA** bitácora con horas, duración exacta de inmersión, fotos de LEDs y evaluación con estándares de calibración.

## Resultado puntual visible en las consolas Python
| Variable | A | B |
|---|---:|---:|
| Temperatura | 21,81 °C | 5,88 °C |
| TDS | 250,10 ppm | 892,33 ppm |
| Turbidez | 0,00 NTU | 403,06 NTU |
| Envío a ThingSpeak reportado | ID 1 | ID 2 |

A cumple los tres umbrales programados y B los incumple. La respuesta física de LEDs no aparece en estas capturas; no afirmar que fue observada. Ver [`datos/`](datos/) y [`reportes/`](reportes/).

## Encuesta pre-test
El Avance 3 informa 46 participantes, seguridad percibida **2,67/5**, capacidad percibida **2,11/5**, utilidad **4,07/5**, y **65,2%** que no conocía factores que afectan el tratamiento. Son **percepciones**, no ensayos de eficacia ni tests con 46 prototipos.

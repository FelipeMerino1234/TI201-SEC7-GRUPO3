# Datos de laboratorio
- [`lecturas_visibles_2026-11-22.csv`](lecturas_visibles_2026-11-22.csv): las **cinco lecturas anteriores al mensaje EEPROM** visibles en cada Monitor Serial; transcripción fiel.
- [`registros_thingspeak_2026-11-22.csv`](registros_thingspeak_2026-11-22.csv): las **dos lecturas puntuales** que aparecen en las capturas de subida a ThingSpeak.

Los CSV no incluyen timestamps porque las capturas no los muestran. No se agregan fechas/horas artificiales ni se infiere error estadístico de estas pocas lecturas.

**FALTA** exportación completa de ThingSpeak y registros de referencia para evaluar precisión.

# Evidencia original del 22/11/2026
**Archivos originales incluidos** (los nombres WhatsApp se conservan para trazabilidad):

1. `WhatsApp Image 2026-11-22 at 1.36.52 PM.jpeg`: Monitor Serial, muestra A (21,81 °C, TDS aproximadamente 250 ppm, turbidez 0 NTU, mensaje EEPROM).
2. `WhatsApp Image 2026-11-22 at 1.38.00 PM.jpeg`: Windows CMD ejecuta `subir_eva.py`, carga muestra A, registro ThingSpeak **1**.
3. `WhatsApp Image 2026-11-22 at 1.58.29 PM.jpeg`: Monitor Serial, muestra B (fría con sal, TDS cercano a 900 ppm, turbidez creciente, mensaje EEPROM).
4. `WhatsApp Image 2026-11-22 at 1.58.42 PM.jpeg`: Windows CMD ejecuta `subir_eva.py`, carga muestra B, registro ThingSpeak **2**.

**FALTA** captura independiente de los LEDs físicos en ambas condiciones, dashboard con las gráficas y tiempos medidos.

# Resultados experimentales (22/11/2026)
## Dos muestras del protocolo
**A:** agua de la llave. **B:** agua con hielo y sal.

| Parámetro | Lectura subida A | Lectura subida B | Criterio programado |
|---|---:|---:|---|
| Temperatura | 21,81 °C | 5,88 °C | > 10 °C |
| TDS | 250,10 ppm | 892,33 ppm | < 500 ppm |
| Turbidez | 0,00 NTU | 403,06 NTU | < 5 NTU |

El programa configura LED **verde** cuando todos cumplen y **rojo** si cualquiera incumple: A cumple y B incumple. Las capturas no muestran los LEDs encendidos; **FALTA** evidencia física de esa respuesta.

## Medias derivadas de CINCO lecturas de cada muestra
Se calcularon exclusivamente usando los cinco registros visibles **antes del mensaje EEPROM**, no el historial completo de dos minutos:

| Parámetro | Media A | Media B |
|---|---:|---:|
| Temperatura | 21,81 °C | 5,87 °C |
| TDS | 250,35 ppm | 893,51 ppm |
| Turbidez | 0,00 NTU | 394,05 NTU |

Estos promedios son **cálculos derivados de capturas**, no mediciones adicionales ni medias de toda la prueba.

## Persistencia y nube
El Monitor Serial muestra `[EEPROM] Muestra #1 guardada correctamente` y las consolas Python muestran cargas exitosas a ThingSpeak con IDs **1** (A) y **2** (B). La consola del equipo ejecuta **`subir_eva.py`** conectado a COM5. **FALTA** el script original y el historial completo del canal.

## Limitaciones
No se cuantificó latencia real del LED/nube, error metrológico ni porcentaje de clasificaciones incorrectas. Los sensores **no detectan microorganismos** y sus umbrales no certifican potabilidad ni eficacia garantizada de tabletas.

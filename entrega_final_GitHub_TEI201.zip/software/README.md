# Software
## Firmware
Se incluye el archivo original [`src/EVA.ino`](src/EVA.ino), escrito para **Arduino Uno**. El GitHub ya contiene `src/main.ino`, otra versión que se conserva sin sobrescribir.

El firmware usa `OneWire.h`, `DallasTemperature.h` y `EEPROM.h`. Pines: DS18B20 D2; interruptor D3 con `INPUT_PULLUP`; TDS A0; turbidez A1; LED verde D8; rojo D9. Comunicación serial a **9600 baudios**. Promedia diez conversiones analógicas por ciclo, aplica compensación térmica al TDS y offset (+0,74 V) a la turbidez. Evalúa temperatura >10 °C, turbidez <5 NTU, TDS <500 ppm. El firmware contiene una capacidad configurada de **85 registros EEPROM** y guarda una muestra después de cinco ciclos de lectura con el interruptor activo. `L` exporta CSV serial y `B` borra el contador de registros.

**FALTA:** documentar y validar con referencia externa la exactitud de las calibraciones.

## Gateway Python
Las capturas muestran un script llamado **`subir_eva.py`** conectado a **COM5** y respuestas exitosas del canal ThingSpeak. **FALTA** el código de ese script: no se inventó un reemplazo. Para utilizarlo será necesario instalar `pyserial` y probablemente `requests`, según lo declarado en los informes; sus versiones exactas no están verificadas.

## Instrucciones
1. Abrir `src/EVA.ino` en Arduino IDE con la placa Arduino Uno.
2. Instalar OneWire y DallasTemperature desde Library Manager.
3. Subir código y conectar el Monitor Serial a 9600 baudios.
4. El comando `L` imprime cabecera `Muestra,Temp_C,TDS_ppm,Turbidez_NTU` seguida de registros EEPROM; `B` borra el contador del historial. **Advertencia:** la operación B es destructiva y no debe ejecutarse antes de respaldar.
5. Cerrar el Monitor Serial antes de abrir el puerto USB desde Python.

**FALTA:** instrucciones del gateway basadas en el archivo real y credenciales seguras (nunca subir claves API a GitHub).

# Lógica del sistema
1. DS18B20 produce una temperatura por ciclo.
2. Entradas analógicas A0 (TDS) y A1 (turbidez): se toman y promedian **10 lecturas** por ciclo.
3. Conversión a TDS ppm y NTU según ecuaciones incluidas en `EVA.ino`.
4. Comparación de tres umbrales de control; rojo si alguna variable los incumple, verde en caso contrario.
5. Serial 9600 baudios; registro EEPROM tras cinco ciclos con interruptor activo; comando `L` para listado, `B` para borrado.
6. En la sesión documentada, Python (`subir_eva.py`) envió dos registros desde COM5 a ThingSpeak.

**FALTA:** el programa Python original para documentar su formato de peticiones, sus intervalos reales de subida y el manejo de errores. **FALTA:** validar físicamente en esa sesión LEDs, precisión y tiempos.

**Nota de seguridad:** EEPROM guarda valores, no verifica potabilidad. No asegurar seguridad microbiológica en base a TDS/NTU/temperatura.

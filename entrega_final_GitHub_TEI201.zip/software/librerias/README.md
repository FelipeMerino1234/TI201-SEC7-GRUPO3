# Dependencias verificadas por el código
- `OneWire.h`: protocolo 1-Wire para DS18B20.
- `DallasTemperature.h`: lectura del sensor de temperatura.
- `EEPROM.h`: librería estándar Arduino de persistencia.
- `analogRead()`: lectura de TDS y turbidez; no requieren una librería particular en el código disponible.

Instalar OneWire y DallasTemperature desde el gestor de Arduino IDE. **FALTA** captura de compilación y versiones exactas utilizadas en la máquina del equipo.

El informe indica Python con serial y envío HTTP hacia ThingSpeak, pero **FALTA** el script original y por ello no se fijan dependencias ni versiones como hechos demostrados.

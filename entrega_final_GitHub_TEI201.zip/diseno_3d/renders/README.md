# Renders
El Avance 3 contiene imágenes incrustadas que describe como vista exterior isométrica y vista interior/explosionada del encapsulado.

**FALTA** exportar los archivos originales PNG/JPG de esos renders desde Fusion 360. No utilizar imágenes generadas para sustituir supuestas pruebas de impresión real.

# Diseño mecánico 3D
El Avance 3 describe un encapsulado de **52 × 100 × 253 mm**, con electrónica superior, zona inferior de inmersión de sensores, orificio de evacuación de aire y tapa superior desmontable, modelado en Fusion 360. El documento declara **197 g de PLA** como consumo/masa de material estimado.

GitHub ya contiene **`DISEÑO.f3d` en la raíz**. Se conserva allí hasta revisar el CAD; la carpeta `fusion360/` explica cómo abrirlo. La presencia del archivo no demuestra automáticamente que incluya cada componente del gemelo digital.

**FALTA** archivos independientes de planos exportados y renders en sus carpetas. **FALTA** evidencia de fabricación física en impresora 3D y prueba de estanqueidad, cuando corresponda.

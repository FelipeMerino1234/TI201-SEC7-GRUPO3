# Planos técnicos
El Avance 3 describe vistas ortogonales del cuerpo principal, tapa removible y ensamble general; varias imágenes aparecen incrustadas en el informe original.

**FALTA** exportación independiente a PDF de planos normalizados (cuerpo, tapa, conjunto), con cotas, escalas y tolerancias verificables. No inventar dimensiones de orificios ni tolerancias faltantes.

# Archivo fuente Fusion 360
El repositorio original contiene `DISEÑO.f3d` en la **raíz**, no aquí: [abrir archivo original](../../DISE%C3%91O.f3d).

Según Avance 3, la evolución de dimensiones pasa del modelo anterior de **70 × 120 × 270 mm** a **52 × 100 × 253 mm**. El diseño contempla cámaras diferenciadas, tapa removible y paso de cableado.

**FALTA** abrir el archivo original para confirmar el historial paramétrico y la presencia exacta de todas las piezas internas, tolerancias y relaciones. No se inventa contenido del `.f3d` sin inspeccionarlo.
